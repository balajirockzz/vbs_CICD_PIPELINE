import subprocess
import json_handler
import sys

# collect required files from local chekout..

json_file_path = sys.argv[1]
input_parm = json_handler.json.loads(sys.argv[2])
artifact_indv_sec = json_handler.read_json(json_file_path + "artifact_indv.json")
artifact_indv_sec_data = json_handler.read_json(json_file_path + "artifact_indv_sec_data.json")


class database_artifact:
    def __init__(self, username, password, artifact_list, source_repo, connection_string, artifact_type):
        self.username = username
        self.password = password
        self.artifact_list = artifact_list
        self.connection_string = connection_string
        self.source_repo = source_repo
        self.artifact_type = artifact_type

    def execute(self, sql_file):
        print("Execution Block")
        artifact_indv_sec_metadata = artifact_indv_sec_data
        contains_error = "no"
        db_command = f'''sql -S "{self.username}/{self.password}@'{self.connection_string}'" <<EOF
                    set heading off
                    set feedback off
                    set termout off
                    spool error.txt
                    @"{self.source_repo}/{sql_file}"
                    spool off'''
        try:
            subprocess.run(db_command, shell=True, check=True)
            
            with open("error.txt", 'r') as file:
                lines = file.readlines()
            error_lines = []
            found_error = False
            
            for line in lines:
                
                if line.startswith("Error report -"):
                    found_error = True
                if found_error:
                    contains_error = "yes"
                    error_lines.append((line.strip()))
                else:
                    contains_error ="no"
                    error_logs = "{file} Artifact Deployed Successfully".format(file=sql_file)

                
            error_logs=("".join(error_lines))
            print("error:", error_logs)
            
            Message = error_logs

        except subprocess.CalledProcessError as e:
            contains_error = "yes"
            Message = "Error While Execution-{e}"

        finally:

            artifact_indv_sec_metadata["contains_error"] = contains_error
            artifact_indv_sec_metadata["name"] = sql_file
            artifact_indv_sec_metadata["payload"] = Message
            print(artifact_indv_sec_metadata)

        return artifact_indv_sec_metadata

    def upload(self):

        print("Artifact_list", self.artifact_list)
        artifact_indv_sec["section"].append(artifact_type)
        artifact_indv_sec["section_data"].update({artifact_type: []})
        artifact_indv_sec["artifact_name"] = artifact_indv_sec["artifact_name"].replace("##artifact_name##",
                                                                                        artifact_type)
        for sql_file in self.artifact_list:
            print("SQL File name:", sql_file)
            out_json = self.execute(sql_file)
            print("out json", out_json)
            # artifacts.insert(0,out_json)
            artifact_indv_sec["section_data"][artifact_type].append(out_json.copy())
            

        

        if artifact_type == "Database":
            update_deployment_info = artifact_indv_sec["deployment_info"]
            update_deployment_info["db_env"] = self.connection_string
            update_deployment_info["oic_env"] = "NA"
            update_deployment_info["report_env"] = "NA"

        return artifact_indv_sec


if __name__ == "__main__":
    artifact_type = "Database"
    a = database_artifact(input_parm["username"], input_parm["password"], input_parm["artifact_list"],
                          input_parm["source_repo"], input_parm["url"], artifact_type)
    json_handler.create_json(a.upload())
