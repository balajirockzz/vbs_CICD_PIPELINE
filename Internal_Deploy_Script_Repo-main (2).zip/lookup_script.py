
from multiprocessing import cpu_count as _cpu_count
import requests
from requests.auth import HTTPBasicAuth
import json
import os
import sys

try:
    from zipfile import ZipFile
except ImportError:
    os.system('pip install zipfile')
    os.system('pip list')

from zipfile import ZipFile

WAIT_TIME = 5
MAX_RUN_COUNT = _cpu_count()
responseResult = []
headers = {'X-HTTP-Method-Override': 'PATCH', 'Accept': 'application/json'}


def deploy_lookup(url, user, passs, method, filepath, file_source_location):
    lookup_import_url = '/ic/api/integration/v1/lookups/archive'
    files = {
        'file': open("/".join(file_source_location.split("/")[:-1] if file_source_location.split("/")[-1] == "" else file_source_location.split("/"))+"/"+filepath, 'rb'),
        'type': (None, 'application/octet-stream'),
    }
    lookup_import = requests.request(method, url + lookup_import_url, headers=headers, auth=HTTPBasicAuth(user, passs),
                               files=files)
    if str(lookup_import.status_code).startswith("20"):
        print("{filepath}: DEPLOYED".format(filepath=filepath))
        raise Exception("SUCCESS: {filepath}: DEPLOYED".format(filepath=filepath))
    else:
        lookup_deploy = json.loads(lookup_import.content)
        print("{filepath}: NOT DEPLOYED ".format(filepath=filepath))
        print("Error: {error}".format(error=lookup_deploy["detail"]))
        raise Exception("ERROR: {error}".format(error=lookup_deploy["detail"]))


def integrations(url, user, passs, oci_filepath, file_source_location):
    # Intialize variable values
    print("Recieved Filepath: {V_FILEPATHS}".format(V_FILEPATHS=oci_filepath))
    print("Iterating over filepaths and processing for deployment......")
    import_put_post = 'put'
    lookup_check_url = '/ic/api/integration/v1/lookups/'
    artifact_type = "OIC"
    if 'OIC' not in artifact_indv_sec["section"]:
        artifact_indv_sec["section"].append(artifact_type)
        artifact_indv_sec["section_data"][artifact_type] = []
    artifact_indv_sec["deployment_info"]["oic_env"] = artifact_indv_sec["deployment_info"]["oic_env"].replace(
        "##oic_env##", url)

    for filepath in oci_filepath:
        print("###################################{filepath}###############################".format(filepath=filepath))
        artifact_indv_sec_data = {
            "name": "#name#",
            "contains_error": "#contains_error#",
            "payload": "#payload#"
        }

        if filepath.lower().endswith(".csv"):
            try:
                fileName, fileExtension = filepath.split('.')[0].strip(), filepath.split('.')[1].strip()
                print("Checking the status of the {filepath} Lookup".format(filepath=filepath))
                filetype = "LOOKUP"

                lookup_status = requests.get(url + lookup_check_url + fileName, headers=headers,
                                             auth=HTTPBasicAuth(user, passs))
                if json.loads(lookup_status.content)["status"] == "HTTP 404 Not Found":
                    import_put_post = 'post'
                    print(json.loads(lookup_status.content)["title"])
                    deploy_lookup(url, user, passs, import_put_post, filepath, file_source_location)
                else:
                    print(json.loads(lookup_status.content))
                    deploy_lookup(url, user, passs, import_put_post, filepath, file_source_location)
                    # raise Exception("SUCCESS: {filepath}: DEPLOYED".format(filepath=filepath))

            except Exception as e:
                print("{e}".format(filepath=filepath, e=e))
                print(artifact_indv_sec_data)
                artifact_indv_sec_data['name'] = artifact_indv_sec_data['name'].replace("#name#", filepath)
                artifact_indv_sec_data["payload"] = artifact_indv_sec_data["payload"].replace("#payload#", str(e))
                # artifact_indv_sec_data["subtype"] = artifact_indv_sec_data["subtype"].replace("#subtype#", filetype)

                if str(e).split(":")[0] == "ERROR":
                    artifact_indv_sec_data["contains_error"] = artifact_indv_sec_data["contains_error"]. \
                        replace("#contains_error#", "yes")
                elif str(e).split(":")[0] == "SUCCESS":
                    artifact_indv_sec_data["contains_error"] = artifact_indv_sec_data["contains_error"].replace(
                        "#contains_error#", "no")
                print(artifact_indv_sec_data)
                artifact_indv_sec["section_data"][artifact_type].append(artifact_indv_sec_data)


def create_json(json_file):
    obj_count = 0
    artifact_status = []
    for item in json_file["section"]:
        obj_count += len(json_file["section_data"][item])
        for value in json_file["section_data"][item]:
            if value["contains_error"] == "yes":
                artifact_status.append(1)
            elif value["contains_error"] == "no":
                artifact_status.append(0)

    json_file["deployment_info"]["status"] = json_file["deployment_info"]["status"]. \
        replace("##status##", 'Contains Error' if any(artifact_status) == True else 'Deployment Successfully Done')
    json_file["deployment_info"]["obj_count"] = json_file["deployment_info"]["obj_count"].replace("##obj_count##",
                                                                                                  str(obj_count))

    json_obj = json.dumps(json_file, indent=4)
    with open("int_dash.json", "w") as file:
        file.write(json_obj)


def read_json(json_file):
    f = open(json_file, "r")
    return json.loads(f.read())


if __name__ == "__main__":
    json_file_path = sys.argv[1]
    input_parm = json.loads(sys.argv[2])
    artifact_indv_sec = read_json(json_file_path + "artifact_indv.json")
    artifact_indv_sec_data = read_json(json_file_path + "artifact_indv_sec_data.json")
    a = integrations(input_parm["url"], input_parm["username"], input_parm["password"], input_parm["artifact_list"], input_parm["source_repo"])
    create_json(artifact_indv_sec)
