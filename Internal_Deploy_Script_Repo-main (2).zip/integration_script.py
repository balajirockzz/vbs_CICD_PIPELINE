
from multiprocessing import cpu_count as _cpu_count
import requests
from requests.auth import HTTPBasicAuth
import json
import os
import sys

WAIT_TIME = 5
MAX_RUN_COUNT = _cpu_count()
responseResult = []
headers = {'X-HTTP-Method-Override': 'PATCH', 'Accept': 'application/json'}

#####################################################Integrations Deployments#############################


def act_deactivate_iar(url, user, passs, id, status):  # Activate and deactivate the integrations using this method
    iar_deac_act_url = '/ic/api/integration/v1/integrations/'
    if status == "ACTIVATED":
        payload = {'status': 'ACTIVATED'}
        iar_act = requests.post(url + iar_deac_act_url + str(id), headers=headers,
                                auth=HTTPBasicAuth(user, passs), json=payload)
    else:
        payload = {'status': 'CONFIGURED'}
        iar_act = requests.post(url + iar_deac_act_url + id, headers=headers,
                                auth=HTTPBasicAuth(user, passs), json=payload)
    iar_act = json.loads(iar_act.content)
    if iar_act["status"] != status:
        print("{id} : {title}".format(id=id, title=iar_act["title"]))
        return "Error"
    else:
        print("{id}: {status}!".format(id=id, status=status))
        return "Success"


def deploy_filepath(url, user, passs, method, filepath, file_source_location):
    iar_import_url = 'ic/api/integration/v1/integrations/archive'
    print("{method}ting the integrations for: {filepath}".format(filepath=filepath, method=method))

    files = {
        'file': open(file_source_location + filepath, 'rb'),
        'type': (None, 'application/octet-stream'),
    }
    o_iar_deploy = requests.request(method, url + iar_import_url, headers=headers,
                                    auth=HTTPBasicAuth(user, passs),
                                    files=files)

    print(o_iar_deploy)
    if str(o_iar_deploy.status_code).startswith("20"):
        print("{filepath}: DEPLOYED".format(filepath=filepath))
        print("Activating Integration....")
        act_result = act_deactivate_iar(url, user, passs, os.path.splitext(filepath)[0], "ACTIVATED")
        if act_result == "Success":
            print("{file_name}: ACTIVATED".format(file_name=filepath))
            raise Exception("SUCCESS: {file_name} ACTIVATED and DEPLOYED".format(file_name=filepath))
        elif act_result == "Error":
            print("{file_name}: got error while ACTIVATING".format(file_name=filepath))
            raise Exception("ERROR: {file_name} got error while ACTIVATING".format(file_name=filepath))
    else:
        o_iar_deploy = json.loads(o_iar_deploy.content)
        print(o_iar_deploy)
        if o_iar_deploy["status"] == "HTTP 500 Internal Server Error":
            raise Exception("ERROR: " + o_iar_deploy["status"] + o_iar_deploy["title"])
        else:
            raise Exception("ERROR: " + o_iar_deploy)



def integrations(url, user, passs, oci_filepath, file_source_location):
    # Intialize variable values
    print("Recieved Filepath: {V_FILEPATHS}".format(V_FILEPATHS=oci_filepath))
    print("Iterating over filepaths and processing for deployment......")
    import_put_post = 'put'
    iar_check_url = 'ic/api/integration/v1/integrations/'
    artifact_type = "OIC"
    if 'OIC' not in artifact_indv_sec["section"]:
        artifact_indv_sec["section"].append(artifact_type)
        artifact_indv_sec["section_data"][artifact_type] = []
    artifact_indv_sec["deployment_info"]["oic_env"] = artifact_indv_sec["deployment_info"]["oic_env"].replace(
        "##oic_env##", url)

    for filepath in oci_filepath:
        print("###################################{filepath}###############################".format(filepath=filepath))
        artifact_indv_sec_data = {
            "name": "#name#",
            "contains_error": "#contains_error#",
            "payload": "#payload#"
        }


        if filepath.lower().endswith(".iar"):
            try:
                result=os.path.splitext(filepath)
                fileName, fileExtension = "_".join(result[0].split('_')[:-1]), result[1]
                version = result[0].split("_")[-1].strip()
                filetype = "IAR"
                print("Checking the status of the {filepath} integration".format(filepath=filepath))
                o_iar_status = requests.get(url + iar_check_url + fileName + "|" + version, headers=headers,
                                            auth=HTTPBasicAuth(user, passs))
                # If the status is ACTIVATED
                o_iar_status = json.loads(o_iar_status.content)
                print(o_iar_status)
                if o_iar_status["status"] == "ACTIVATED":
                    print("Integrations Status: ACTIVATED")
                    print("Deactivating the integrations..")
                    # Deactivating the IAR Integration
                    act_result = act_deactivate_iar(url, user, passs,os.path.splitext(filepath)[0], "CONFIGURED")
                    if act_result == "Success":
                        print("SUCCESS: {file_name} DE_ACTIVATED".format(file_name=filepath))
                    elif act_result == "Error":
                        print("{file_name}: got error while DE_ACTIVATING".format(file_name=filepath))
                        raise Exception("ERROR: {file_name} got error while DE_ACTIVATING".format(file_name=filepath))

                elif o_iar_status["status"] == "HTTP 404 Not Found":
                    print("Integration not found")
                    import_put_post = 'post'

                else:
                    print("Integration Status: CONFIGURED")
                    import_put_post='put'
                # Deploying Integration
                print("Deploying Integration....")
                deploy_filepath(url, user, passs, import_put_post, filepath, file_source_location)

            except Exception as e:
                print("{e}".format(filepath=filepath, e=e))
                print(artifact_indv_sec_data)
                artifact_indv_sec_data['name'] = artifact_indv_sec_data['name'].replace("#name#", filepath)
                artifact_indv_sec_data["payload"] = artifact_indv_sec_data["payload"].replace("#payload#", str(e))

                if str(e).split(":")[0] == "ERROR":
                    artifact_indv_sec_data["contains_error"] = artifact_indv_sec_data["contains_error"]. \
                        replace("#contains_error#", "yes")
                elif str(e).split(":")[0] == "SUCCESS":
                    artifact_indv_sec_data["contains_error"] = artifact_indv_sec_data["contains_error"].replace(
                        "#contains_error#", "no")
                print(artifact_indv_sec_data)
                artifact_indv_sec["section_data"][artifact_type].append(artifact_indv_sec_data)


def create_json(json_file):
    obj_count = 0
    artifact_status = []
    for item in json_file["section"]:
        obj_count += len(json_file["section_data"][item])
        for value in json_file["section_data"][item]:
            if value["contains_error"] == "yes":
                artifact_status.append(1)
            elif value["contains_error"] == "no":
                artifact_status.append(0)

    json_file["deployment_info"]["status"] = json_file["deployment_info"]["status"]. \
        replace("##status##", 'Contains Error' if any(artifact_status) == True else 'Deployment Successfully Done')
    json_file["deployment_info"]["obj_count"] = json_file["deployment_info"]["obj_count"].replace("##obj_count##",
                                                                                                  str(obj_count))

    json_obj = json.dumps(json_file, indent=4)
    with open("int_dash.json", "w") as file:
        file.write(json_obj)


def read_json(json_file):
    f = open(json_file, "r")
    return json.loads(f.read())


if __name__ == "__main__":
    json_file_path = sys.argv[1]
    input_parm= json.loads(sys.argv[2])
    artifact_indv_sec = read_json(json_file_path + "artifact_indv.json")
    artifact_indv_sec_data = read_json(json_file_path + "artifact_indv_sec_data.json")
    a = integrations(input_parm["url"], input_parm["username"], input_parm["password"], input_parm["artifact_list"], input_parm["source_repo"])
    create_json(artifact_indv_sec)
