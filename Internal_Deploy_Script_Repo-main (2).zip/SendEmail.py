import smtplib, ssl
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
import base64
import json
import os
import sys

try:
    import oci
except ImportError:
    os.system('pip install oci')

import oci


class SMTP_SERVER:
    def __init__(SMTP, sender, subject):
        SMTP.sender = sender
        SMTP.subject = subject

    def get_credentials(SMTP):
        config = oci.config.from_file()
        secrets_client = oci.secrets.SecretsClient(config)
        get_secret_bundle_by_name_response = secrets_client.get_secret_bundle_by_name(
            secret_name="DPLOY_SMTP",
            vault_id="ocid1.vault.oc1.iad.dvsdpkd5aae2w.abuwcljsql4rnfdal6vdrllbbto2lcmy4eah4qbartyw27mdcbb72u2ory3a"
        )
        base64_Secret_content = get_secret_bundle_by_name_response.data.secret_bundle_content.content
        base64_secret_bytes = base64_Secret_content.encode('ascii')
        base64_message_bytes = base64.b64decode(base64_secret_bytes)
        secret_content = base64_message_bytes.decode('ascii')
        secret_content_json = json.loads(secret_content)
        SMTP.OCI_SMTP_USERID = secret_content_json["USERNAME"]
        SMTP.OCI_SMTP_HOST = secret_content_json["SMTP_SERVER"]
        SMTP.OCI_SMTP_PORT = secret_content_json["PORT"]
        SMTP.OCI_SMTP_PASS = secret_content_json["PASSWORD"]
        SMTP.OCI_SMTP_RECEIVERS = secret_content_json["RECEIVERS"]

    def create_email(mail):
        msg = MIMEMultipart()
        filename = sys.argv[3]
        report_file = open(filename)
        html = report_file.read()
        email_body = """<p> 
        <p style="font-size:15px">Hi,</p>
        <p style="font-size:15px">Please refer the deployment information or <a href="https://delmarketsol-nacaus19.developer.ocp.oraclecloud.com/delmarketsol-nacaus19/#projects/artifact-deployment-project/cibuild/jobs/test%20mail/builds/{build_id}/log">click here</a> to view from VBS tool
        </p>{html}
        <p style="font-size:15px">Thanks</p>""".format(build_id=sys.argv[2],html=html.replace('<nav class="navbar navbar-inverse"><ul class="nav navbar-nav"><li><a href="#">Deployment Summary</a></li></ul></nav>'," "))
        msg.attach(MIMEText(email_body, 'html'))
        msg['From'] = mail.sender
        msg['To'] = mail.OCI_SMTP_RECEIVERS[0]
        msg['Subject'] = mail.subject
        mail.msg = msg

    def send_email(mail):
        try:
            server = smtplib.SMTP(mail.OCI_SMTP_HOST, mail.OCI_SMTP_PORT)
            server.ehlo()  # Can be omitted
            server.starttls(context=ssl.create_default_context())  # Secure the connection
            server.ehlo()  # Can be omitted
            server.login(mail.OCI_SMTP_USERID, mail.OCI_SMTP_PASS)
            server.sendmail(mail.sender, mail.OCI_SMTP_RECEIVERS, mail.msg.as_string())
        except Exception as e:
            print(e)
        finally:
            server.quit()


sender = "vbs.abhi.kute@gmail.com"
subject = "VBS {env} {art_type} Deployment Summary ".format(env=sys.argv[4],art_type=sys.argv[5])

email_server = SMTP_SERVER(sender, subject)
email_server.get_credentials()
email_server.create_email()
email_server.send_email()

