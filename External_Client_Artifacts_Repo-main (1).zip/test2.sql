-- Example SQL file
 
-- Create a table
-- ALTER TABLE employees
-- ADD email varchar(50);
 
-- Insert data into the table
INSERT INTO USER_DETAILS (USER_ID, NAME)
VALUES (11, 'DeshpandeTest2');
