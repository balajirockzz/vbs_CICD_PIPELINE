@test_function.sql
SELECT CalculateSquare(5) FROM DUAL;

@test_packge.sql
DECLARE
    squared_value NUMBER;
BEGIN
    squared_value := MathPackage.CalculateSquare(5);
    MathPackage.PrintMessage('The square is: ' || TO_CHAR(squared_value));
END;