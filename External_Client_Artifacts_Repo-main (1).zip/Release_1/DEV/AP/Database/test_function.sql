CREATE OR REPLACE FUNCTION CalculateSquare(input_number IN NUMBER) RETURN NUMBER IS
    result NUMBER;
BEGIN
    result := input_number * input_number;
    RETURN result;
END CalculateSquare;
/
COMMIT;